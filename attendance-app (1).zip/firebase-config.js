// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyArjztr_ReDN6ZGEeMy2FieQYSr8z_uFGQ",
  authDomain: "attendanceapp-388d8.firebaseapp.com",
  projectId: "attendanceapp-388d8",
  storageBucket: "attendanceapp-388d8.appspot.com",
  messagingSenderId: "340887011249",
  appId: "1:340887011249:web:6210093c97d3e04e2cc790"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
